﻿using System;
using Microsoft.Extensions.Configuration;

namespace SodexoAyuda.API.Util
{
    public static class Constants
    {
        public const string JWT_KEY = "session_user";

        public static string SecretKey = "";
        public static byte[] byteKey = null;
        public static byte[] byteIV = null;

        public static string ReactPassword = "";

        public static string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return Convert.ToBase64String(plainTextBytes);
        }

        public static string Base64Decode(string base64EncodedData)
        {
            var base64EncodedBytes = Convert.FromBase64String(base64EncodedData);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }

        public static string GetConfigValue(string key)
        {
            var result = default(string);

            result = Environment.GetEnvironmentVariable(key);
            if (string.IsNullOrEmpty(result))
                result = Startup.StaticConfig.GetValue<string>(key);

            return result ?? string.Empty;
        }
    }
}