﻿namespace SodexoAyuda.API.Entities
{
    public class CommonResponse
    {
        public string value { get; set; }
        public string status { get; set; }
        public string id { get; set; }
        public string detalle { get; set; }

        //public class T
        //{

        //}
    }
}
