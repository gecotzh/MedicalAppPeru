﻿using System.Collections.Generic;

namespace SodexoAyuda.API.Entities
{
    public class MailSettings
    {
        public string UserName { get; set; }
        public int PortNumber { get; set; }
        public string HostName { get; set; }
        public bool EnableSSL { get; set; }
        public string FromEmail { get; set; }

        public List<string> BccMails { get; set; }
    }
}
