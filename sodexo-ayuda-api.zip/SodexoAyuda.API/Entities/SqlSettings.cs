﻿using SodexoAyuda.API.Util;

namespace SodexoAyuda.API.Entities
{
    public class SqlSettings
    {
        public string ConnectionString { get; set; }
        public string Database { get; set; }

        public string DecodeConnectionStirng()
        {
            return Constants.Base64Decode(ConnectionString);
        }
    }

    public class OracleSettings
    {
        public string ConnectionString { get; set; }
        public string Database { get; set; }

        public string DecodeConnectionStirng()
        {
            return Constants.Base64Decode(ConnectionString);
        }
    }
}
