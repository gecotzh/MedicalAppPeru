﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net;

namespace SodexoAyuda.API.Entities
{
    public class ErrorResponse
    {
        public string message { get; set; }
        public int statusCode { get; set; }
        public string error { get; set; }

        public ErrorResponse()
        {

        }

        public static ContentResult GetErrorContent() => GetErrorContent("Datos no encontrados");

        public static ContentResult GetErrorContent(string message)
        {
            var error = new ErrorResponse();

            error.message = message;
            error.statusCode = (int)HttpStatusCode.BadRequest;
            error.error = "001";

            var mensajeError = JsonConvert.SerializeObject(error);

            return new ContentResult()
            {
                Content = mensajeError,
                StatusCode = error.statusCode
            };
        }
    }
}
