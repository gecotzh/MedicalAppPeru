﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SodexoAyuda.API.Entities.DTO
{
    public class Producto
    {
        public string id { get; set; }
        public string type { get; set; }
        public string name { get; set; }
        public string description { get; set; }
        public bool bin { get; set; }
        public bool isWarning { get; set; }
        public string cardId { get; set; }
        public string cardSubId { get; set; }
    }
}
