﻿namespace SodexoAyuda.API.Entities.DTO
{
    public class MovimientoResponse
    {
        public string TipoDocumento { get; set; }
        public string NumeroDocumento { get; set; }
        public string Beneficiario { get; set; }
        public string RucOrganizacion { get; set; }
        public string Organizacion { get; set; }
        public string Fecha { get; set; }
        public string Tarjeta { get; set; }
        public string Movimiento { get; set; }
        public decimal? Monto { get; set; }
        public string Estado { get; set; }
    }
}
