﻿namespace SodexoAyuda.API.Entities.DTO
{
    public class PedidoItemResponse
    {
        public string DocumentType { get; set; }
        public string DocumentNumber { get; set; }
        public string BeneficiaryName { get; set; }
        public string StatusType { get; set; }
        public string OperationType { get; set; }
        public string CardNumber { get; set; }
        public decimal Amount { get; set; }
    }
}
