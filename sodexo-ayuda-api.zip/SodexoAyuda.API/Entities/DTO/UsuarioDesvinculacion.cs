﻿namespace SodexoAyuda.API.Entities.DTO
{
    public class UsuarioDesvinculacion
    {
        public string Code { get; set; }
        public string Name{ get; set; }
        public string DocumentNumber { get; set; }
        public string EmailAccount { get; set; }
        public string PhoneNumber { get; set; }
    }
}
