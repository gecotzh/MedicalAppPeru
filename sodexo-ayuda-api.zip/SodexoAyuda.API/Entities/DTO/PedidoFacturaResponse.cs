﻿namespace SodexoAyuda.API.Entities.DTO
{
    public class PedidoFacturaResponse
    {
        public string InvoiceType { get; set; }
        public string Status { get; set; }
        public string ProductType { get; set; }
        public string InvoiceDate { get; set; }
        public string ReferenceNumber { get; set; }
        public string Description { get; set; }
        public decimal Total { get; set; }
        public string PartyCompleteName { get; set; }
    }
}
