﻿using System.Collections.Generic;

namespace SodexoAyuda.API.Entities.DTO
{
    public class PedidoResponse
    {
        public string OrderId { get; set; }
        public string OrderDate { get; set; }
        public string ObservationMessage { get; set; }
        public string OrderType { get; set; }
        public string StatusType { get; set; }
        public decimal TotalOrder { get; set; }
        public string OrganizationRuc { get; set; }
        public string OrganizationName { get; set; }
        public string ProductName { get; set; }
        public string ProductType { get; set; }
        public string FinanceCategory { get; set; }
        public string InsertedUser { get; set; }

        public string SyncFinancialStatus { get; set; }
        public string CodeDescription { get; set; }

        public List<PedidoItemResponse> OrderItems { get; set; }
        public List<PedidoDocumentoResponse> Documents { get; set; }
        public List<PedidoFacturaResponse> Invoices { get; set; }
    }
}
