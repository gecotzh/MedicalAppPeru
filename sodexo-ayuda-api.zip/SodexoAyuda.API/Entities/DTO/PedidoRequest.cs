﻿namespace SodexoAyuda.API.Entities.DTO
{
    public class PedidoRequest
    {
        public int? OrderId { get; set; }
    }
}
