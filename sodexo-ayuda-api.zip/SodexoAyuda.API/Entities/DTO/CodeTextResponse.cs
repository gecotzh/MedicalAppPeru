﻿namespace SodexoAyuda.API.Entities.DTO
{
    public class CodeTextResponse
    {
        public string Code { get; set; }
        public string Text { get; set; }
    }
}
