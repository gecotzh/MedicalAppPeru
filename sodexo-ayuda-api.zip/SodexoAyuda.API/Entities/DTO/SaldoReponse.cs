﻿namespace SodexoAyuda.API.Entities.DTO
{
    public class SaldoReponse
    {
        public string Dni { get; set; }
        public string Beneficiario { get; set; }
        public string RucOrganizacion { get; set; }
        public string Organizacion { get; set; }
        public string CentroCosto { get; set; }
        public string Tarjeta { get; set; }
        public string Producto { get; set; }
        public decimal? Saldo { get; set; }
        public string EstadoTarjeta { get; set; }
        public string EstadoInterno { get; set; }
        public string CodigoBloqueo { get; set; }
        public string FechaEmision { get; set; }
        public string FechaExpiracion { get; set; }
    }
}
