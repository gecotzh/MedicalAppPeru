﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SodexoAyuda.API.Entities.DTO
{
    public class ProductoCirculacion
    {
        public int key { get; set; }
        public int redemptionDate { get; set; }
        public int expirationDate { get; set; }
        public int number { get; set; }
        public int amount { get; set; }
        public int employeeName { get; set; }
        public int status { get; set; }
    }
}
