﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SodexoAyuda.API.Entities.DTO
{
    public class Proceso
    {
        public string idTarjeta { get; set; }
        public string nombre { get; set; }
        public string tarjetaEnmascarado { get; set; }
        public string documento { get; set; }
        public string email { get; set; }
        public string telefono { get; set; } 
        public string tarjeta { get; set; }
        public string emision { get; set; }
        public string expiracion { get; set; }
        public string estado { get; set; }
        public string internalEstado { get; set; }
        public string lockEstado { get; set; }
        public string estadoDescripcion { get; set; }
        public int bin { get; set; }
    }
}
