﻿using System.Collections.Generic;

namespace SodexoAyuda.API.Entities.DTO
{
    public class ValeRequest
    {
        public string id_pedido { get; set; }
        public string id_producto { get; set; }
        public string ruc_cliente { get; set; }
        public string ruc_proveedor { get; set; }
        public List<string> vales { get; set; }
    }
}
