﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SodexoAyuda.API.Entities.DTO
{
    public class Combo
    {
        public int id { get; set; }
        public string descripcion { get; set; }
    }
}
