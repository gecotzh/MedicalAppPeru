﻿namespace SodexoAyuda.API.Entities.DTO
{
    public class ReporteValesResponse
    {
        public string FechaCanje { get; set; }
        public int IdProducto { get; set; }
        public string ValeCompleto { get; set; }
        public decimal MontoProducto { get; set; }
        public string NumeroEmpleado { get; set; }
        public string NombreEmpleado { get; set; }
        public int IdPedido { get; set; }
        public string NombreCliente { get; set; }
        public string RucCliente { get; set; }
        public string NombreProveedor { get; set; }
        public string RucProveedor { get; set; }
        public int? IdLectura { get; set; }
        public string FechaLectura { get; set; }
        public decimal? MontoDC { get; set; }
    }
}
