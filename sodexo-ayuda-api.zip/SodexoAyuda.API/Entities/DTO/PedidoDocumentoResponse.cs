﻿namespace SodexoAyuda.API.Entities.DTO
{
    public class PedidoDocumentoResponse
    {
        public string DocumentType { get; set; }
        public string StatusType { get; set; }
        public string DocumentTypeNumber { get; set; }
        public string DocumentDate { get; set; }
        public string PartyCompleteName { get; set; }
        public string ContactName { get; set; }
        public string AddressSource { get; set; }
        public string AddressDestination { get; set; }
        public string DeliveryDate { get; set; }
    }
}
