﻿namespace SodexoAyuda.API.Entities.DTO
{
    public class SaldoRequest
    {
        public string Documento { get; set; }
        public string Tarjeta { get; set; }
    }
}
