﻿namespace SodexoAyuda.API.Entities.DTO
{
    public class StatusResponse
    {
        public bool Success { get; set; }
        public string Message { get; set; }
    }
}
