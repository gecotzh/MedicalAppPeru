﻿namespace SodexoAyuda.API.Entities.DTO
{
    public class ValeResponse
    {
        public string FechaCanje { get; set; }
        public string NumeroVale { get; set; }
        public decimal MontoVale { get; set; }
        public string NombreEmpleado { get; set; }
    }
}
