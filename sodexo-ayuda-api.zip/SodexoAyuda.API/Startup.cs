﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using SodexoAyuda.API.Entities;
using SodexoAyuda.API.IRepository;
using SodexoAyuda.API.Repository;
using SodexoAyuda.API.Util;
using System;
using System.Linq;
using System.Text;

namespace SodexoAyuda.API
{
    public class Startup
    {
        public IConfiguration Configuration { get; }
        public static IConfiguration StaticConfig { get; private set; }

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
            StaticConfig = configuration;
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddControllers();


            services.Configure<SqlSettings>(options =>
            {
                options.ConnectionString = Constants.GetConfigValue("SqlConnectionString");
                options.Database = Constants.GetConfigValue("SqlDatabase");
            });

            services.Configure<OracleSettings>(options =>
            {
                options.ConnectionString = Constants.GetConfigValue("OracleConnectionString");
                options.Database = Constants.GetConfigValue("OracleDatabase");
            });

            services.Configure<MailSettings>(options =>
            {
                options.UserName = Constants.GetConfigValue("MailUserName");
                options.PortNumber = int.Parse(Constants.GetConfigValue("MailPortNumber"));
                options.HostName = Constants.GetConfigValue("MailHostName");
                options.EnableSSL = Constants.GetConfigValue("MailEnableSSL") == "1";
                options.FromEmail = Constants.GetConfigValue("MailFromEmail");
            });

            Constants.SecretKey = Constants.GetConfigValue("SecretKey");
            Constants.ReactPassword = Constants.GetConfigValue("ReactPassword");

            var rijndael = Constants.GetConfigValue("RijndaelKey");
            Constants.byteKey = Encoding.ASCII.GetBytes(rijndael.Split(new String[] { "|" }, StringSplitOptions.RemoveEmptyEntries)[0]);
            Constants.byteIV = Encoding.ASCII.GetBytes(rijndael.Split(new String[] { "|" }, StringSplitOptions.RemoveEmptyEntries)[1]);

            services.AddSingleton<SqlSettings>();
            services.AddSingleton<OracleSettings>();

            services.AddTransient<ILoginRepository, LoginRepository>();
            services.AddTransient<IUsuariosConnectRepository, UsuariosConnectRepository>();
            //services.AddTransient<IGeneralRepository, GeneralRepository>();
            services.AddTransient<IValesRepository, ValesRepository>();
            services.AddTransient<ITarjetasRepository, TarjetasRepository>();
            services.AddTransient<IPedidosRepository, PedidosRepository>();
            services.AddTransient<IProductosRepository, ProductosRepository>();

            services.AddControllers();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "SodexoAyuda.API", Version = "v1" });
                c.ResolveConflictingActions(apiDescriptions => apiDescriptions.First()); //This line
            });
            services.AddCors(opt =>
            {
                opt.AddPolicy("CorsRule", rule =>
                {
                    rule.AllowAnyHeader().AllowAnyMethod().WithOrigins("*");
                });
            });

            ///configuracion de token
            var key = Encoding.ASCII.GetBytes(Configuration.GetValue<string>("SecretKey"));

            services.AddAuthentication(x =>
            {
                x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer(x =>
            {
                x.RequireHttpsMetadata = false;
                x.SaveToken = true;
                x.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateIssuer = false,
                    ValidateAudience = false
                };
            });

            //services.AddMvc();

            services.AddSwaggerGen();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c =>
                {
                    c.SwaggerEndpoint("/swagger/v1/swagger.json", "My API V1");//originally "./swagger/v1/swagger.json"
                });
            }

            // Enable middleware to serve generated Swagger as a JSON endpoint.
            app.UseSwagger();

            // Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.)
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "My API V1");
                c.RoutePrefix = string.Empty;
            });

            app.UseRouting();
            app.UseCors("CorsRule");
            app.UseAuthorization();

            app.UseMiddleware<JwtMiddleware>();

            app.UseEndpoints(endpoints => { endpoints.MapControllers(); });

            app.UseAuthentication();
        }
    }
}
