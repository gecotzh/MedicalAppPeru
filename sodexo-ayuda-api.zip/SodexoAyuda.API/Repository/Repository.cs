﻿using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;
using SodexoAyuda.API.Entities;
using SodexoAyuda.API.Entities.DTO;
using SodexoAyuda.API.Util;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace SodexoAyuda.API.Repository
{
    public abstract class Repository
    {
        protected string cadenaConexion;
        protected SqlConnection _context;
        protected SqlTransaction _transaction;

        public Repository(string connectionString)
        {
            cadenaConexion = connectionString;
        }

        public Repository(IOptions<SqlSettings> options)
        {
            cadenaConexion = options.Value.ConnectionString;
        }

        protected SqlCommand CreateCommand(string query) => CreateCommand(query, null);

        protected SqlCommand CreateCommand(string query, params SqlParameter[] values)
        {
            var sqlCommand = new SqlCommand(query, _context, _transaction);

            if (values != null)
                sqlCommand.Parameters.AddRange(values);

            return sqlCommand;
        }

        #region Get Command...

        protected SqlCommand GetCommand(string query) => GetCommand(query, CommandType.StoredProcedure);

        protected SqlCommand GetCommand(string query, CommandType commandType = CommandType.StoredProcedure) => GetCommand(query, commandType, null);

        protected SqlCommand GetCommand(string query, string name, object value) => GetCommand(query, CommandType.StoredProcedure, new SqlParameter(name, value));

        protected SqlCommand GetCommand(string query, params SqlParameter[] values) => GetCommand(query, CommandType.StoredProcedure, values);

        protected SqlCommand GetCommand(string query, CommandType commandType = CommandType.StoredProcedure, params SqlParameter[] values)
        {
            var connection = new SqlConnection(cadenaConexion);
            var command = new SqlCommand(query, connection);

            if (values != null)
                command.Parameters.AddRange(values);

            command.CommandType = commandType;
            command.Connection.Open();

            return command;
        }
        #endregion

        #region Get Reader...

        protected SqlDataReader GetReader(string commandText) => GetReader(commandText, CommandType.StoredProcedure);

        protected SqlDataReader GetReader(string commandText, CommandType commandType = CommandType.StoredProcedure) => GetReader(commandText, commandType, null);

        protected SqlDataReader GetReader(string commandText, string name, object value) => GetReader(commandText, CommandType.StoredProcedure, new SqlParameter(name, value));

        protected SqlDataReader GetReader(string commandText, params SqlParameter[] values) => GetReader(commandText, CommandType.StoredProcedure, values);

        protected SqlDataReader GetReader(string commandText, CommandType commandType = CommandType.StoredProcedure, params SqlParameter[] values)
        {
            var connection = new SqlConnection(cadenaConexion);
            var command = new SqlCommand(commandText, connection);

            if (values != null)
                command.Parameters.AddRange(values);

            command.CommandType = commandType;
            command.Connection.Open();

            var reader = command.ExecuteReader();

            return reader;
        }

        protected SqlDataReader GetReaderClose(string commandText) => GetReaderClose(commandText, CommandType.StoredProcedure);

        protected SqlDataReader GetReaderClose(string commandText, CommandType commandType = CommandType.StoredProcedure) => GetReaderClose(commandText, commandType, null);

        protected SqlDataReader GetReaderClose(string commandText, string name, object value) => GetReaderClose(commandText, CommandType.StoredProcedure, new SqlParameter(name, value));

        protected SqlDataReader GetReaderClose(string commandText, params SqlParameter[] values) => GetReaderClose(commandText, CommandType.StoredProcedure, values);

        protected SqlDataReader GetReaderClose(string commandText, CommandType commandType = CommandType.StoredProcedure, params SqlParameter[] values)
        {
            var connection = new SqlConnection(cadenaConexion);
            var command = new SqlCommand(commandText, connection);

            command.CommandType = commandType;

            if (values != null)
                command.Parameters.AddRange(values);

            command.Connection.Open();
            command.CommandTimeout = int.MaxValue;

            var reader = command.ExecuteReader(CommandBehavior.CloseConnection);

            return reader;
        }
        #endregion

        protected async Task<List<CodeTextResponse>> GetListResult(string commandText)
        {
            var items = new List<CodeTextResponse>();

            using (var dr = GetReaderClose(commandText))
            {
                items = dr.Cast<IDataRecord>().Select(s => new CodeTextResponse
                {
                    Code = s.ValueOrDefault<string>(0).ReactEncrypt(),
                    Text = s.ValueOrDefault<string>(1),
                }).ToList();
            }

            return items;
        }
    }
}
