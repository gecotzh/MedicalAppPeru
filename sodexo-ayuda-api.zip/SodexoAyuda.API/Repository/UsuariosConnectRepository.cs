﻿using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;
using SodexoAyuda.API.Entities;
using SodexoAyuda.API.Entities.DTO;
using SodexoAyuda.API.IRepository;
using SodexoAyuda.API.Util;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace SodexoAyuda.API.Repository
{
    public class UsuariosConnectRepository : Repository, IUsuariosConnectRepository
    {
        public UsuariosConnectRepository(IOptions<SqlSettings> options) : base(options)
        {
        }

        public Task<UsuarioDesvinculacion> GetUsuario(string obj)
        {
            UsuarioDesvinculacion oDatos = null;

            try
            {
                using (var reader = GetReaderClose("EXPERIS.USP_CONSULTA_CUENTA_SODEXO_CLUB", "@codigo", obj))
                {
                    if (reader.Read())
                    {
                        oDatos = new UsuarioDesvinculacion();
                        oDatos.Code = reader.ValueOrDefault<long>("UsuarioId").ToString().ReactEncrypt();
                        oDatos.Name = reader.ValueOrDefault("PARTY_COMPLETE_NAME");
                        oDatos.DocumentNumber = reader.ValueOrDefault("DOCUMENT_TYPE_NUMBER");
                        oDatos.EmailAccount = reader.ValueOrDefault("Email");
                        oDatos.PhoneNumber = reader.ValueOrDefault("Telefono");
                    }
                }
            }
            catch (Exception ex)
            {
                oDatos = null;
                Task.FromResult(ex);
            }

            return Task.FromResult(oDatos);
        }


        public Task<CommonResponse> Desvincular(string sessionUser, UsuarioDesvinculacion usuario)
        {
            CommonResponse oDatos = new CommonResponse();

            try
            {
                using (var cmd = GetCommand("EXPERIS.DESVINCULAR_CUENTA"
                    , new SqlParameter("@SESSION_USER", sessionUser)
                    , new SqlParameter("@UsuarioId", usuario.Code.ReactDecrypt())
                    , new SqlParameter("@Mensaje", SqlDbType.VarChar, 100) { Direction = ParameterDirection.Output }
                    ))
                {
                    cmd.ExecuteNonQuery();

                    var requestStatus = (string)cmd.Parameters["@Mensaje"].Value;
                    var vmensaje = requestStatus.Split('|');

                    oDatos.value = vmensaje[1];
                    oDatos.status = vmensaje[0];
                }
            }
            catch (Exception ex)
            {
                Task.FromResult(ex);
            }

            return Task.FromResult(oDatos);
        }
    }
}
