﻿using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;
using SodexoAyuda.API.Entities;
using SodexoAyuda.API.Entities.DTO;
using SodexoAyuda.API.IRepository;
using SodexoAyuda.API.Util;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace SodexoAyuda.API.Repository
{
    public class TarjetasRepository : Repository, ITarjetasRepository
    {

        public TarjetasRepository(IOptions<SqlSettings> sqlSettings) : base(sqlSettings)
        {
        }

        public async Task<List<SaldoReponse>> ConsultaSaldos(List<SaldoRequest> filters)
        {
            var listSaldos = new List<SaldoReponse>();

            try
            {
                var dt = new DataTable();

                dt.Columns.Add("DOCUMENT_TYPE_NUMBER");
                dt.Columns.Add("PARTY_COMPLETE_NAME");
                dt.Columns.Add("CARD_NUMBER");

                foreach (var item in filters)
                {
                    dt.Rows.Add(item.Documento, null, item.Tarjeta);
                }

                using (var con = new SqlConnection(cadenaConexion))
                {
                    using (var cmd = new SqlCommand("EXPERIS.CONSULTA_SALDOS_TARJETAS", con))
                    {
                        await con.OpenAsync();

                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter()
                        {
                            Value = dt,
                            TypeName = "EXPERIS.LIST_BENEFICIARIO_TARJETA",
                            SqlDbType = SqlDbType.Structured,
                            ParameterName = "@LIST_TARJETAS"
                        });

                        using (var dr = await cmd.ExecuteReaderAsync())
                        {
                            while (dr.Read())
                            {
                                listSaldos.Add(new SaldoReponse
                                {
                                    Dni = dr.GetString(0),
                                    Beneficiario = dr.GetString(1),
                                    RucOrganizacion = dr.GetString(2),
                                    Organizacion = dr.GetString(3),
                                    CentroCosto = dr.GetString(4),
                                    Tarjeta = dr.GetString(5),
                                    Producto = dr.GetString(6),
                                    Saldo = dr.IsDBNull(7) ? null : dr.GetDecimal(7),
                                    EstadoTarjeta = dr.GetString(8),
                                    EstadoInterno = dr.GetString(9),
                                    CodigoBloqueo = dr.GetString(10),
                                    FechaEmision = dr.GetString(11),
                                    FechaExpiracion = dr.GetString(12)
                                });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return listSaldos;
        }

        public async Task<List<MovimientoResponse>> ConsultaMovimientos(List<MovimientoRequest> filters)
        {
            var listSaldos = new List<MovimientoResponse>();

            try
            {
                var dt = new DataTable();

                dt.Columns.Add("DOCUMENT_TYPE_NUMBER");
                dt.Columns.Add("PARTY_COMPLETE_NAME");
                dt.Columns.Add("CARD_NUMBER");

                foreach (var item in filters)
                {
                    dt.Rows.Add(item.Documento, null, item.Tarjeta);
                }

                using (var con = new SqlConnection(cadenaConexion))
                {
                    using (var cmd = new SqlCommand("EXPERIS.CONSULTA_MOVIMIENTOS_TARJETAS", con))
                    {
                        await con.OpenAsync();

                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandTimeout = 240;
                        cmd.Parameters.Add(new SqlParameter()
                        {
                            Value = dt,
                            TypeName = "EXPERIS.LIST_BENEFICIARIO_TARJETA",
                            SqlDbType = SqlDbType.Structured,
                            ParameterName = "@LIST_TARJETAS"
                        });

                        using (var dr = await cmd.ExecuteReaderAsync())
                        {
                            while (dr.Read())
                            {
                                listSaldos.Add(new MovimientoResponse
                                {
                                    TipoDocumento = dr.GetStringValue(0),
                                    NumeroDocumento = dr.GetStringValue(1),
                                    Beneficiario = dr.GetStringValue(2),
                                    RucOrganizacion = dr.GetStringValue(3),
                                    Organizacion = dr.GetStringValue(4),
                                    Fecha = dr.GetStringValue(5),
                                    Tarjeta = dr.GetStringValue(6),
                                    Movimiento = dr.GetStringValue(7),
                                    Monto = dr.IsDBNull(8) ? null : dr.GetDecimal(8),
                                    Estado = dr.GetStringValue(9),
                                });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return listSaldos;
        }

        public async Task<List<CodeTextResponse>> ListadoEstadosProceso() => await GetListResult("EXPERIS.TARJETAS_LISTAR_ESTADOS_PROCESAR");

        public async Task<List<Proceso>> GetListCards(List<Proceso> filters)
        {
            List<Proceso> listCards = new List<Proceso>();

            try
            {
                var table = new DataTable();

                table.Columns.Add("DOCUMENT_TYPE_NUMBER", typeof(string));
                table.Columns.Add("PARTY_COMPLETE_NAME", typeof(string));
                table.Columns.Add("CARD_NUMBER", typeof(string));

                foreach (var item in filters)
                {
                    table.Rows.Add(item.documento, null, item.tarjeta);
                }

                using (SqlConnection connection = new SqlConnection(cadenaConexion))
                {
                    await connection.OpenAsync();

                    using (SqlCommand cmd = new SqlCommand("EXPERIS.LISTA_ESTADO_TARJETAS", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@LISTADO_TARJETAS", table)
                        {
                            SqlDbType = SqlDbType.Structured,
                            TypeName = "EXPERIS.LIST_BENEFICIARIO_TARJETA"
                        });

                        using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                        {
                            while (reader.Read())
                            {
                                Proceso obj = new Proceso();

                                obj.idTarjeta = reader.ValueOrDefault<int>(0).ToString().ReactEncrypt();
                                obj.emision = reader.ValueOrDefault("EMISSION_DATE");
                                obj.expiracion = reader.ValueOrDefault("EXPIRATION_DATE");
                                obj.estado = reader.ValueOrDefault("STATUS_TYPE_DESC");
                                obj.internalEstado = reader.ValueOrDefault("INTERNAL_LOCK_DESC");
                                obj.lockEstado = reader.ValueOrDefault("LOCK_CODE");
                                obj.nombre = reader.ValueOrDefault("PARTY_COMPLETE_NAME");
                                obj.estadoDescripcion = reader.ValueOrDefault("STATUS_TYPE_DESC");
                                obj.tarjetaEnmascarado = reader.ValueOrDefault("CARD_MASKED");
                                obj.documento = reader.ValueOrDefault("DOCUMENT_TYPE_DESC");

                                listCards.Add(obj);
                            }
                        }
                    };
                }
            }
            catch (Exception ex)
            {
                throw ex;

            }

            return listCards;
        }

        public async Task<List<CommonResponse>> UpdateStatus(string sessionUser, List<Proceso> oDetalle)
        {
            List<CommonResponse> oDatos = new List<CommonResponse>();

            try
            {
                var table = new DataTable();

                table.Columns.Add("DOCUMENT_TYPE_NUMBER", typeof(string));
                table.Columns.Add("PARTY_COMPLETE_NAME", typeof(string));
                table.Columns.Add("CARD_NUMBER", typeof(string));

                foreach (var item in oDetalle)
                {
                    table.Rows.Add(null, null, item.idTarjeta.ReactDecrypt());
                }

                var status = oDetalle.First().estado.ReactDecrypt();

                using (var cmd = GetCommand("EXPERIS.CAMBIAR_ESTADO_TARJETA_MASIVO"
                    , new SqlParameter("@USERNAME", sessionUser)
                    , new SqlParameter("@STATUS", status)
                    , new SqlParameter("@TARJETAS", table)
                    {
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "EXPERIS.LIST_BENEFICIARIO_TARJETA"
                    }
                ))
                {
                    await cmd.ExecuteNonQueryAsync();

                    oDatos = oDetalle.Select(s => new CommonResponse
                    {
                        status = "success",
                        value = "Cambio de estado con exito",
                        id = s.idTarjeta
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return oDatos;
        }
    }
}
