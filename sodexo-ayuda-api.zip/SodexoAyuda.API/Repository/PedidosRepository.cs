﻿using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;
using SodexoAyuda.API.Entities;
using SodexoAyuda.API.Entities.DTO;
using SodexoAyuda.API.IRepository;
using SodexoAyuda.API.Util;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace SodexoAyuda.API.Repository
{
    public class PedidosRepository : BaseRepository, IPedidosRepository
    {
        public PedidosRepository(IOptions<SqlSettings> sqlSettings, IOptions<OracleSettings> oracleSettings) : base(sqlSettings, oracleSettings)
        {
        }

        public async Task<List<CodeTextResponse>> ListadoEstados() => await GetListResult("EXPERIS.PEDIDOS_LISTAR_ESTADOS");

        public async Task<List<CodeTextResponse>> ListadoTipos() => await GetListResult("EXPERIS.PEDIDOS_LISTAR_TIPOS");

        private void ValidateOrderId(string orderId)
        {
            if (string.IsNullOrEmpty(orderId))
            {
                throw new Exception("No se ha brindado la información del pedido");
            }
        }

        public async Task<PedidoResponse> OrderInfo(string orderId)
        {
            PedidoResponse pedido = null;

            try
            {
                ValidateOrderId(orderId);

                using (var con = new SqlConnection(cadenaConexion))
                {
                    await con.OpenAsync();

                    using (var cmd = new SqlCommand("EXPERIS.CONSULTAR_INFO_PEDIDO", con))
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@order_id", orderId);

                        using (var dr = await cmd.ExecuteReaderAsync())
                        {
                            if (dr.Read())
                            {
                                pedido = new PedidoResponse()
                                {
                                    OrderId = dr.ValueOrDefault<int>(0).ToString().ReactEncrypt(),
                                    OrderDate = dr.ValueOrDefault<string>(1),
                                    ObservationMessage = dr.ValueOrDefault<string>(2),
                                    OrderType = dr.ValueOrDefault<string>(3),
                                    StatusType = dr.ValueOrDefault<string>(4),
                                    TotalOrder = dr.ValueOrDefault<decimal>(5),
                                    OrganizationRuc = dr.ValueOrDefault<string>(6),
                                    OrganizationName = dr.ValueOrDefault<string>(7),
                                    ProductName = dr.ValueOrDefault<string>(8),
                                    ProductType = dr.ValueOrDefault<string>(9),
                                    FinanceCategory = dr.ValueOrDefault<string>(10),
                                    InsertedUser = dr.ValueOrDefault<string>(11)
                                };
                            }

                            dr.NextResult();

                            if (pedido != null)
                            {
                                pedido.OrderItems = new List<PedidoItemResponse>();

                                while (dr.Read())
                                {
                                    pedido.OrderItems.Add(new PedidoItemResponse()
                                    {
                                        DocumentType = dr.ValueOrDefault<string>(0),
                                        DocumentNumber = dr.ValueOrDefault<string>(1),
                                        BeneficiaryName = dr.ValueOrDefault<string>(2),
                                        StatusType = dr.ValueOrDefault<string>(3),
                                        OperationType = dr.ValueOrDefault<string>(4),
                                        CardNumber = dr.ValueOrDefault<string>(5),
                                        Amount = dr.ValueOrDefault<decimal>(6)
                                    });
                                }
                            }
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                throw;
            }

            return pedido;
        }


        public async Task<string> AnularPedio(string sessionUser, string orderId)
        {
            ValidateOrderId(orderId);

            using (var con = new SqlConnection(cadenaConexion))
            {
                await con.OpenAsync();

                var msj = "";

                using (var cmd = new SqlCommand("EXPERIS.PEDIDO_ANULAR_PEDIDO", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@SESSION_USER", sessionUser);
                    cmd.Parameters.AddWithValue("@ORDER_ID", orderId.ReactDecrypt());
                    cmd.Parameters.Add(new SqlParameter()
                    {
                        ParameterName = "@MESSAGE",
                        Size = 1000,
                        Direction = ParameterDirection.Output
                    });

                    await cmd.ExecuteNonQueryAsync();

                    msj = cmd.Parameters[1].Value.ToString();
                }

                return msj;
            }
        }

        public async Task<string> CambiarEstadoPedido(string sessionUser, PedidoResponse pedido)
        {
            using (var con = new SqlConnection(cadenaConexion))
            {
                await con.OpenAsync();

                var trx = con.BeginTransaction();
                var message = "";
                var mistake = "";

                using (var cmd = new SqlCommand("EXPERIS.UPDATE_ORDER_STATUS", con, trx))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@SESSION_USER", sessionUser);
                    cmd.Parameters.AddWithValue("@ORDER_ID", pedido.OrderId.ReactDecrypt());
                    cmd.Parameters.AddWithValue("@ORDER_STATUS", pedido.StatusType.ReactDecrypt());
                    cmd.Parameters.AddWithValue("@UPDATE", true);

                    cmd.Parameters.Add(new SqlParameter
                    {
                        Size = 1000,
                        ParameterName = "@MESSAGE",
                        Direction = ParameterDirection.InputOutput
                    });

                    cmd.Parameters.Add(new SqlParameter
                    {
                        Size = 1000,
                        ParameterName = "@MISTAKE",
                        Direction = ParameterDirection.InputOutput
                    });

                    await cmd.ExecuteNonQueryAsync();

                    message = cmd.GetParameterValue("@MESSAGE");
                    mistake = cmd.GetParameterValue("@MISTAKE");

                    if (!string.IsNullOrEmpty(mistake))
                        message = mistake;
                }

                trx.Commit();

                return message;
            }
        }

        public async Task<string> CambiarTipoPedido(string sessionUser, PedidoResponse pedido)
        {
            using (var con = new SqlConnection(cadenaConexion))
            {
                await con.OpenAsync();

                var trx = con.BeginTransaction();
                var message = "";
                var mistake = "";

                using (var cmd = new SqlCommand("EXPERIS.UPDATE_ORDER_TYPE", con, trx))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@SESSION_USER", sessionUser);
                    cmd.Parameters.AddWithValue("@ORDER_ID", pedido.OrderId.ReactDecrypt());
                    cmd.Parameters.AddWithValue("@STATUS", pedido.OrderType.ReactDecrypt());
                    cmd.Parameters.AddWithValue("@UPDATE", true);

                    cmd.Parameters.Add(new SqlParameter
                    {
                        Size = 1000,
                        ParameterName = "@MESSAGE",
                        Direction = ParameterDirection.InputOutput
                    });

                    cmd.Parameters.Add(new SqlParameter
                    {
                        Size = 1000,
                        ParameterName = "@MISTAKE",
                        Direction = ParameterDirection.InputOutput
                    });

                    await cmd.ExecuteNonQueryAsync();

                    message = cmd.GetParameterValue("@MESSAGE");
                    mistake = cmd.GetParameterValue("@MISTAKE");

                    if (!string.IsNullOrEmpty(mistake))
                        message = mistake;
                }

                trx.Commit();

                return message;
            }
        }

        public async Task<PedidoResponse> ConsultaRetorno(string orderId)
        {
            var pedido = new PedidoResponse()
            {
                Documents = new List<PedidoDocumentoResponse>(),
                Invoices = new List<PedidoFacturaResponse>()
            };

            try
            {
                ValidateOrderId(orderId);

                using (var con = new SqlConnection(cadenaConexion))
                {
                    using (var cmd = new SqlCommand("EXPERIS.CONSULTA_PEDIDO_RETORNO", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@ORDER_ID", orderId.ReactDecrypt());

                        await cmd.Connection.OpenAsync();

                        using (var dr = await cmd.ExecuteReaderAsync())
                        {
                            if (dr.Read())
                            {
                                pedido.CodeDescription = dr.ValueOrDefault(0);
                                pedido.SyncFinancialStatus = dr.ValueOrDefault(1);
                            }

                            await dr.NextResultAsync();

                            pedido.Documents = dr.Cast<IDataRecord>().Select(s => new PedidoDocumentoResponse
                            {
                                DocumentType = s.ValueOrDefault(0),
                                StatusType = s.ValueOrDefault(1),
                                DocumentTypeNumber = s.ValueOrDefault(2),
                                DocumentDate = s.ValueOrDefault(3),
                                PartyCompleteName = s.ValueOrDefault(4),
                                ContactName = s.ValueOrDefault(5),
                                AddressSource = s.ValueOrDefault(6),
                                AddressDestination = s.ValueOrDefault(7),
                                DeliveryDate = s.ValueOrDefault(8),
                            }).ToList();

                            await dr.NextResultAsync();

                            pedido.Invoices = dr.Cast<IDataRecord>().Select(s => new PedidoFacturaResponse
                            {
                                InvoiceType = s.ValueOrDefault(0),
                                Status = s.ValueOrDefault(1),
                                ProductType = s.ValueOrDefault(2),
                                InvoiceDate = s.ValueOrDefault(3),
                                ReferenceNumber = s.ValueOrDefault(4),
                                Description = s.ValueOrDefault(5),
                                Total = s.ValueOrDefault<decimal>(6),
                                PartyCompleteName = s.ValueOrDefault(7),
                            }).ToList();
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return pedido;
        }

        public async Task<string> RetornoAlFacturador(string sessionUser, string orderId)
        {
            ValidateOrderId(orderId);

            using (var con = new SqlConnection(cadenaConexion))
            {
                await con.OpenAsync();

                var trx = con.BeginTransaction();
                var message = "";
                var mistake = "";

                using (var cmd = new SqlCommand("EXPERIS.PEDIDO_EJECUTAR_RETORNO_FACTURADOR", con, trx))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ORDER_ID", orderId.ReactDecrypt());
                    cmd.Parameters.AddWithValue("@USERNAME", sessionUser);

                    cmd.Parameters.Add(new SqlParameter
                    {
                        Size = 1000,
                        ParameterName = "@MESSAGE",
                        Direction = ParameterDirection.InputOutput
                    });

                    cmd.Parameters.Add(new SqlParameter
                    {
                        Size = 1000,
                        ParameterName = "@MISTAKE",
                        Direction = ParameterDirection.InputOutput
                    });

                    await cmd.ExecuteNonQueryAsync();

                    message = cmd.GetParameterValue("@MESSAGE");
                    mistake = cmd.GetParameterValue("@MISTAKE");

                    if (!string.IsNullOrEmpty(mistake))
                        message = mistake;
                }

                trx.Commit();

                return message;
            }
        }
    }
}
