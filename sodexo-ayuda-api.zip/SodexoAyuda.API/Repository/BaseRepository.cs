﻿using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;
using SodexoAyuda.API.Entities;
using SodexoAyuda.API.Entities.DTO;
using SodexoAyuda.API.Util;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace SodexoAyuda.API.Repository
{
    public class BaseRepository
    {
        protected readonly string cadenaConexion;
        protected readonly string cadenaConexionOracle;

        public BaseRepository(IOptions<SqlSettings> sqlSettings, IOptions<OracleSettings> oracleSettings)
        {
            cadenaConexion = sqlSettings.Value.ConnectionString;
            cadenaConexionOracle = oracleSettings.Value.ConnectionString;
        }

        protected async Task<SqlDataReader> ExecuteReaderClose(string commandText, params SqlParameter[] values)
        {
            var con = new SqlConnection(cadenaConexion);
            var cmd = new SqlCommand(commandText, con);

            cmd.CommandType = CommandType.StoredProcedure;

            if (values != null)
                cmd.Parameters.AddRange(values);

            await con.OpenAsync();

            return await cmd.ExecuteReaderAsync(CommandBehavior.CloseConnection);
        }

        protected async Task<List<CodeTextResponse>> GetListResult(string commandText)
        {
            var items = new List<CodeTextResponse>();

            using (var dr = await ExecuteReaderClose(commandText))
            {
                items = dr.Cast<IDataRecord>().Select(s => new CodeTextResponse
                {
                    Code = s.ValueOrDefault<string>(0).ReactEncrypt(),
                    Text = s.ValueOrDefault<string>(1),
                }).ToList();
            }

            return items;
        }
    }
}
