﻿using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;
using SodexoAyuda.API.Entities;
using SodexoAyuda.API.Entities.DTO;
using SodexoAyuda.API.IRepository;
using SodexoAyuda.API.Util;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace SodexoAyuda.API.Repository
{
    public class ProductosRepository : BaseRepository, IProductosRepository
    {
        public ProductosRepository(IOptions<SqlSettings> sqlSettings, IOptions<OracleSettings> oracleSettings) : base(sqlSettings, oracleSettings)
        {
        }

        public async Task<CommonResponse> ActualizarBIN(string sessionUser, Producto oDetalle)
        {
            CommonResponse oDatos = new CommonResponse();
            string[] vmensaje;

            try
            {
                using (SqlConnection connection = new SqlConnection(cadenaConexion))
                {
                    await connection.OpenAsync();

                    using (SqlCommand cmd = new SqlCommand("EXPERIS.UPDATEBIN", connection) { CommandType = CommandType.StoredProcedure })
                    {
                        cmd.Parameters.AddWithValue("@SESSION_USER", sessionUser);
                        cmd.Parameters.AddWithValue("@ID", oDetalle.id.ReactDecrypt());
                        cmd.Parameters.AddWithValue("@bin", oDetalle.bin);

                        SqlParameter RuturnValue = new SqlParameter("@Mensaje", SqlDbType.VarChar, 100);

                        RuturnValue.Direction = ParameterDirection.Output;

                        cmd.Parameters.Add(RuturnValue);

                        await cmd.ExecuteNonQueryAsync();

                        string RequestStatus = (string)cmd.Parameters["@Mensaje"].Value;

                        vmensaje = RequestStatus.Split('|');

                        oDatos.status = vmensaje[0];
                        oDatos.value = vmensaje[1];
                        oDatos.detalle = vmensaje[2];
                        oDatos.id = oDetalle.id.ToString();
                    }

                    await connection.CloseAsync();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return oDatos;
        }

        public async Task<List<Producto>> ListarProductos()
        {
            var oDatos = new List<Producto>();

            try
            {
                using (SqlConnection connection = new SqlConnection(cadenaConexion))
                {
                    await connection.OpenAsync();

                    SqlCommand cmd = new SqlCommand();

                    cmd.CommandText = "EXPERIS.LISTPRODUCT";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = connection;

                    using (SqlDataReader reader = await cmd.ExecuteReaderAsync(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            Producto obj = new Producto();

                            obj.id = reader["ID"].ToString().ReactEncrypt();
                            obj.type = (reader["PRODUCT_TYPE_DESC"].ToString());
                            obj.name = (reader["PRODUCT_NAME"].ToString());
                            obj.description = (reader["DESCRIPTION"].ToString());
                            obj.bin = bool.Parse(reader["BIN"].ToString());

                            obj.cardId = reader["CARD_ID"].ToString().ReactEncrypt();
                            obj.cardSubId = reader["SUB_CARD_ID"].ToString().ReactEncrypt();

                            obj.isWarning = reader.ValueOrDefault<bool>("ESTADO_BIN");

                            oDatos.Add(obj);
                        }
                    }

                    await connection.CloseAsync();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return oDatos;
        }
    }
}
