﻿using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;
using SodexoAyuda.API.Entities;
using SodexoAyuda.API.Entities.DTO;
using SodexoAyuda.API.IRepository;
using SodexoAyuda.API.Util;
using System;
using System.Net;
using System.Net.Mail;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace SodexoAyuda.API.Repository
{
    public class LoginRepository : Repository, ILoginRepository
    {
        private readonly MailSettings mailSettings;

        public LoginRepository(IOptions<SqlSettings> options, IOptions<MailSettings> mailSettings) : base(options.Value.ConnectionString)
        {
            this.mailSettings = mailSettings.Value;
        }

        public Task<Usuario> GetUsuario(Usuario usuario)
        {
            Usuario oDatos = new Usuario();

            try
            {
                using (SqlDataReader reader = GetReaderClose("EXPERIS.USP_LOGIN_SODEXO_AYUDA"
                    , new SqlParameter("@username", usuario.usuario)
                    , new SqlParameter("@password", usuario.pass)
                ))
                {
                    if (reader.Read())
                    {
                        oDatos.nombre = reader.ValueOrDefault("DISPLAY_NAME");
                        oDatos.usuario = reader.ValueOrDefault("USERNAME");
                        oDatos.email = reader.ValueOrDefault("EMAIL");
                    }
                }
            }
            catch (Exception ex)
            {
                Task.FromResult(ex);
            }

            return Task.FromResult(oDatos);
        }

        public Task<StatusResponse> RetrieveCredentials(Usuario usuario)
        {
            var response = new StatusResponse();

            try
            {
                Usuario userInfo = null;

                using (SqlDataReader reader = GetReaderClose("EXPERIS.USP_RETRIEVE_CREDENTIALS_SODEXO_AYUDA", "@username", usuario.usuario))
                {
                    if (reader.Read())
                    {
                        userInfo = new Usuario();
                        userInfo.nombre = reader.ValueOrDefault("DISPLAY_NAME");
                        userInfo.usuario = reader.ValueOrDefault("USERNAME");
                        userInfo.email = reader.ValueOrDefault("EMAIL");
                        userInfo.pass = reader.ValueOrDefault("PASSWORD");
                    }
                }

                if (userInfo != null)
                {
                    var bodyMessage = $"Buen día.<br /><br />A través de nuestro sistema Sodexo Ayuda, " +
                        $"usted ha solicitado la recuperación de la contraseña del usuario <b>${userInfo.usuario}</b>, " +
                        $"se la brindaremos a continuación: <br /><br /><b>Perteneciente a: </b>{userInfo.nombre}<br />" +
                        $"<b>Contraseña: </b>{userInfo.pass}" +
                        $"<br /><br />Saludos cordiales.";

                    // Envío de correo
                    using (MailMessage mm = new MailMessage())
                    {
                        mm.From = new MailAddress(mailSettings.UserName, mailSettings.FromEmail);

                        mm.To.Add(userInfo.email);

                        if (mailSettings.BccMails != null)
                        {
                            foreach (var email in mailSettings.BccMails)
                            {
                                mm.Bcc.Add(email);
                            }
                        }

                        mm.Subject = "Sodexo Ayuda - Recuperación de contraseña";
                        mm.Body = bodyMessage;
                        mm.IsBodyHtml = true;
                        mm.BodyEncoding = UTF8Encoding.UTF8;
                        mm.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;

                        ServicePointManager.ServerCertificateValidationCallback = delegate (object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };

                        SmtpClient client = new SmtpClient(mailSettings.HostName);

                        client.UseDefaultCredentials = false;
                        client.Port = mailSettings.PortNumber;
                        client.EnableSsl = mailSettings.EnableSSL;

                        //client.Send(mm);
                    }

                    // Mensaje de respuesta
                    var partesCorreo = userInfo.email.Split("@");
                    var cuenta = partesCorreo[0];

                    response.Message = String.Format("Se ha enviado un mensaje al correo electrónico {0}*****@{1} con las credenciales del usuario."
                        , cuenta.Length > 5 ? cuenta.Substring(0, 5) : cuenta
                        , partesCorreo[1]);

                    response.Success = true;
                }
                else
                {
                    response.Message = "No se ha encontrado el usuario en nuestro registros";
                }
            }
            catch (Exception ex)
            {
                Task.FromResult(ex);
            }

            return Task.FromResult(response);
        }
    }
}
