﻿using Microsoft.Extensions.Options;
using Oracle.ManagedDataAccess.Client;
using SodexoAyuda.API.Entities;
using SodexoAyuda.API.Entities.DTO;
using SodexoAyuda.API.IRepository;
using SodexoAyuda.API.Util;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace SodexoAyuda.API.Repository
{
    public class ValesRepository : IValesRepository
    {
        private readonly string cadenaConexionoracle;

        public ValesRepository(IOptions<OracleSettings> oracle)
        {
            cadenaConexionoracle = oracle.Value.ConnectionString;
        }

        public async Task<List<ValeResponse>> ObtenerVales(ValeRequest filter)
        {
            var listVales = new List<ValeResponse>();

            var id_pedido = filter.id_pedido;
            var id_producto = filter.id_producto;
            var ruc_cliente = filter.ruc_cliente;
            var ruc_proveedor = filter.ruc_proveedor;

            try
            {
                using (var con = new OracleConnection(cadenaConexionoracle))
                {
                    using (var cmd = new OracleCommand("EXPERIS.CONSULTA_VALES", con))
                    {
                        var pCursor = new OracleParameter("CUR_DATA", OracleDbType.RefCursor) { Direction = ParameterDirection.InputOutput };

                        cmd.Parameters.Add("P_ID_PEDIDO", OracleDbType.Decimal, 6, string.IsNullOrEmpty(id_pedido) ? Convert.DBNull : id_pedido, ParameterDirection.Input);
                        cmd.Parameters.Add("P_ID_PRODUCTO", OracleDbType.Decimal, 10, string.IsNullOrEmpty(id_producto) ? Convert.DBNull : id_producto, ParameterDirection.Input);
                        cmd.Parameters.Add("P_RUC_CLIENTE", OracleDbType.Varchar2, 100, string.IsNullOrEmpty(ruc_cliente) ? Convert.DBNull : ruc_cliente, ParameterDirection.Input);
                        cmd.Parameters.Add("P_RUC_PROVEEDOR", OracleDbType.Varchar2, 100, string.IsNullOrEmpty(ruc_proveedor) ? Convert.DBNull : ruc_proveedor, ParameterDirection.Input);
                        cmd.Parameters.Add(pCursor);

                        cmd.CommandType = CommandType.StoredProcedure;

                        await cmd.Connection.OpenAsync();

                        using (var dr = await cmd.ExecuteReaderAsync())
                        {
                            int i = 0;

                            while (dr.Read())
                            {
                                i++;
                                listVales.Add(
                                    new ValeResponse
                                    {
                                        FechaCanje = dr.IsDBNull("FECHA_CANJE") ? null : dr["FECHA_CANJE"].ToString(),
                                        NumeroVale = dr["VALE_PRODUCTO"].ToString().ReactEncrypt(),
                                        MontoVale = dr.GetDecimal("MONTO_PRODUCTO"),
                                        NombreEmpleado = dr.IsDBNull("NOMBRE_EMPLEADO") ? null : dr["NOMBRE_EMPLEADO"].ToString(),
                                    }
                                );
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return listVales;
        }
    }
}
