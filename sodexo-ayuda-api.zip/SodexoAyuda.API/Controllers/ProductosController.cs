﻿using Microsoft.AspNetCore.Mvc;
using SodexoAyuda.API.Entities;
using SodexoAyuda.API.Entities.DTO;
using SodexoAyuda.API.IRepository;
using System.Threading.Tasks;

namespace SodexoAyuda.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductosController : ApiControllerBase
    {
        private readonly IProductosRepository productosRepositoty;

        public ProductosController(IProductosRepository pProductosRepositoty)
        {
            productosRepositoty = pProductosRepositoty;
        }

        [HttpGet()]
        public async Task<IActionResult> Lista()
        {
            var response = await productosRepositoty.ListarProductos();

            if (response.Count <= 0)
            {
                return ErrorResponse.GetErrorContent();
            }

            return Ok(response);
        }

        [HttpPost("UpdateBIN")]
        public async Task<IActionResult> UpdateBIN(Producto obj)
        {
            var response = await productosRepositoty.ActualizarBIN(SESSION_USER, obj);

            if (response.value == null)
            {
                return ErrorResponse.GetErrorContent();
            }
            
            return Ok(response);
        }
    }
}
