﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SodexoAyuda.API.Entities;
using SodexoAyuda.API.Entities.DTO;
using SodexoAyuda.API.IRepository;
using System;
using System.Threading.Tasks;

namespace SodexoAyuda.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuariosConnectController : ApiControllerBase
    {
        private readonly IUsuariosConnectRepository _repository;

        public UsuariosConnectController(IUsuariosConnectRepository repository)
        {
            _repository = repository;
        }

        [HttpGet("BuscarCuenta/{id}")]
        public async Task<IActionResult> Lista(string id)
        {
            var response = await _repository.GetUsuario(id);

            if (response == null)
            {
                return ErrorResponse.GetErrorContent();
            }

            return Ok(response);
        }

        [HttpPost("Desvincular")]
        public async Task<IActionResult> Desvincular(UsuarioDesvinculacion usuario)
        {
            try
            {
                var response = await _repository.Desvincular(SESSION_USER, usuario);

                if (response.value == null)
                {
                    return ErrorResponse.GetErrorContent();
                }
                
                return Ok(response);
            }
            catch (Exception ex)
            {
                return Ok(JsonConvert.SerializeObject(ex));
            }
        }
    }
}
