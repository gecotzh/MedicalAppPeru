﻿using Microsoft.AspNetCore.Mvc;
using SodexoAyuda.API.Entities.DTO;
using SodexoAyuda.API.IRepository;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SodexoAyuda.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PedidosController : ApiControllerBase
    {
        private readonly IPedidosRepository pedidosRepository;

        public PedidosController(IPedidosRepository pedidosRepository)
        {
            this.pedidosRepository = pedidosRepository;
        }

        [HttpGet("ListadoEstados")]
        public async Task<List<CodeTextResponse>> ListadoEstados() => await pedidosRepository.ListadoEstados();

        [HttpGet("ListadoTipos")]
        public async Task<List<CodeTextResponse>> ListadoTipos() => await pedidosRepository.ListadoTipos();


        [HttpGet("{order=null}")]
        public async Task<PedidoResponse> OrderInfo(string order) => await pedidosRepository.OrderInfo(order);

        [HttpGet("AnularPedido/{order=null}")]
        public async Task<string> AnularPedido(string order) => await pedidosRepository.AnularPedio(SESSION_USER, order);

        [HttpPost("CambiarEstado")]
        public async Task<string> CambiarEstado(PedidoResponse pedido) => await pedidosRepository.CambiarEstadoPedido(SESSION_USER, pedido);

        [HttpPost("CambiarTipo")]
        public async Task<string> CambiarTipo(PedidoResponse pedido) => await pedidosRepository.CambiarTipoPedido(SESSION_USER, pedido);

        [HttpGet("ConsultaRetorno/{order=null}")]
        public async Task<PedidoResponse> ConsultaRetorno(string order) => await pedidosRepository.ConsultaRetorno(order);

        [HttpGet("RetornoAlFacturador/{order=null}")]
        public async Task<string> RetornoAlFacturador(string order) => await pedidosRepository.RetornoAlFacturador(order, SESSION_USER);
    }
}
