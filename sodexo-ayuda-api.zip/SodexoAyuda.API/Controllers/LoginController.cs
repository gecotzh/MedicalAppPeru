﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using SodexoAyuda.API.Entities;
using SodexoAyuda.API.Entities.DTO;
using SodexoAyuda.API.IRepository;
using SodexoAyuda.API.Util;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;


namespace SodexoAyuda.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly ILoginRepository _loginService;
        private readonly IConfiguration _configuration;
        public LoginController(ILoginRepository loginService, IConfiguration configuration)
        {
            _loginService = loginService;
            _configuration = configuration;
        }

        [HttpPost("ValidacionUsuario")]
        public async Task<IActionResult> PostLogin(Usuario usuario)
        {

            var response = await _loginService.GetUsuario(usuario);

            if (response.usuario == null)
            {
                return ErrorResponse.GetErrorContent("Usuario o contraseña incorrecta");
            }

            // Leemos el secret_key desde nuestro appseting
            var secretKey = Constants.GetConfigValue("SecretKey");
            var key = Encoding.ASCII.GetBytes(secretKey);

            // Creamos los claims (pertenencias, características) del usuario

            //ClaimsIdentity claims = new ClaimsIdentity();

            //claims.AddClaim(new Claim("user", JsonConvert.SerializeObject(response)));

            var userResponse = JsonConvert.SerializeObject(response);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                //Subject = claims,
                Subject = new ClaimsIdentity(new Claim[] {
                    new Claim(ClaimTypes.Name, userResponse)
                }),

                // Nuestro token va a durar un día
                Expires = DateTime.UtcNow.AddDays(1),

                // Credenciales para generar el token usando nuestro secretykey y el algoritmo hash 256
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var createdToken = tokenHandler.CreateToken(tokenDescriptor);

            var obj = new { response = tokenHandler.WriteToken(createdToken) };
            var data = JsonConvert.SerializeObject(obj);

            return Ok(data);
        }

        [HttpPost("RetrievePassword")]
        public async Task<IActionResult> RetrievePassword(Usuario usuario)
        {
            var response = await _loginService.RetrieveCredentials(usuario);

            return Ok(response);
        }
    }
}
