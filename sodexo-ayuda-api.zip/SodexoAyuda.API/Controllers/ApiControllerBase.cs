﻿using Microsoft.AspNetCore.Mvc;
using SodexoAyuda.API.Util;

namespace SodexoAyuda.API.Controllers
{
    public class ApiControllerBase : ControllerBase
    {
        protected string SESSION_USER
        {
            get
            {
                return HttpContext.Items[Constants.JWT_KEY]?.ToString() ?? null;
            }
        }
    }
}
