﻿using Microsoft.AspNetCore.Mvc;
using SodexoAyuda.API.Entities.DTO;
using SodexoAyuda.API.IRepository;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SodexoAyuda.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValesController : ApiControllerBase
    {
        private readonly IValesRepository valesRepository;

        public ValesController(IValesRepository pValesRepository)
        {
            this.valesRepository = pValesRepository;
        }

        [HttpPost("ObtenerVales")]
        public async Task<List<ValeResponse>> ObtenerVales(ValeRequest filter) => await valesRepository.ObtenerVales(filter);
    }
}
