﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SodexoAyuda.API.Entities;
using SodexoAyuda.API.Entities.DTO;
using SodexoAyuda.API.IRepository;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SodexoAyuda.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TarjetasController : ApiControllerBase
    {
        private readonly ITarjetasRepository tarjetasRepository;

        public TarjetasController(ITarjetasRepository pTarjetasRepository)
        {
            tarjetasRepository = pTarjetasRepository;
        }

        [HttpPost("Listado")]
        public async Task<IActionResult> ListaTarjeta(List<Proceso> tarjetas)
        {
            try
            {
                var response = await tarjetasRepository.GetListCards(tarjetas);

                if (response.Count <= 0)
                {
                    return ErrorResponse.GetErrorContent();
                }

                return Ok(response);
            }
            catch (Exception ex)
            {
                return Ok(JsonConvert.SerializeObject(ex));
            }
        }

        [HttpPost("ActualizarEstado")]
        public async Task<IActionResult> UpdateStatus(List<Proceso> tarjetas)
        {
            try
            {
                var response = await tarjetasRepository.UpdateStatus(SESSION_USER, tarjetas);

                if (response.Count <= 0)
                {
                    return ErrorResponse.GetErrorContent();
                }

                return Ok(response);
            }
            catch (Exception ex)
            {
                return Ok(JsonConvert.SerializeObject(ex));
            }
        }

        [HttpPost("ConsultaSaldos")]
        public async Task<List<SaldoReponse>> ConsultaSaldos(List<SaldoRequest> filters) => await tarjetasRepository.ConsultaSaldos(filters);

        [HttpPost("ConsultaMovimientos")]
        public async Task<List<MovimientoResponse>> ConsultaMovimientos(List<MovimientoRequest> filters) => await tarjetasRepository.ConsultaMovimientos(filters);

        [HttpGet("EstadosProceso")]
        public async Task<List<CodeTextResponse>> EstadosProceso() => await tarjetasRepository.ListadoEstadosProceso();
    }
}
