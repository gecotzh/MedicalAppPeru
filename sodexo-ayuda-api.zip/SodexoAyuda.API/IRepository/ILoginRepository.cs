﻿using SodexoAyuda.API.Entities.DTO;
using System.Threading.Tasks;

namespace SodexoAyuda.API.IRepository
{
   public interface ILoginRepository
    {
        Task<Usuario> GetUsuario(Usuario usurios);
        Task<StatusResponse> RetrieveCredentials(Usuario usuario);
    }
}
