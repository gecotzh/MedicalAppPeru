﻿using SodexoAyuda.API.Entities;
using SodexoAyuda.API.Entities.DTO;
using System.Threading.Tasks;

namespace SodexoAyuda.API.IRepository
{
    public interface IUsuariosConnectRepository
    {
        Task<UsuarioDesvinculacion> GetUsuario(string obj);
        Task<CommonResponse> Desvincular(string sessionUser, UsuarioDesvinculacion usuario);
    }
}
