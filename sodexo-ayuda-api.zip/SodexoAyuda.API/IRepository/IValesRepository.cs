﻿using SodexoAyuda.API.Entities.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SodexoAyuda.API.IRepository
{
    public interface IValesRepository
    {
        Task<List<ValeResponse>> ObtenerVales(ValeRequest filter);
    }
}
