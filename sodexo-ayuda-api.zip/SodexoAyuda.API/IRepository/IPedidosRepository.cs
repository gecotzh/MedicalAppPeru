﻿using SodexoAyuda.API.Entities.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SodexoAyuda.API.IRepository
{
    public interface IPedidosRepository
    {
        Task<PedidoResponse> OrderInfo(string orderId);
        Task<List<CodeTextResponse>> ListadoEstados();
        Task<List<CodeTextResponse>> ListadoTipos();
        Task<PedidoResponse> ConsultaRetorno(string orderId);

        Task<string> AnularPedio(string sessionUser, string orderId);
        Task<string> CambiarTipoPedido(string sessionUser, PedidoResponse pedido);
        Task<string> CambiarEstadoPedido(string sessionUser, PedidoResponse pedido);
        Task<string> RetornoAlFacturador(string sessionUser, string orderId);
    }
}
