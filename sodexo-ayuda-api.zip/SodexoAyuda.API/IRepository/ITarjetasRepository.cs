﻿using SodexoAyuda.API.Entities;
using SodexoAyuda.API.Entities.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SodexoAyuda.API.IRepository
{
    public interface ITarjetasRepository
    {
        Task<List<CodeTextResponse>> ListadoEstadosProceso();
        Task<List<SaldoReponse>> ConsultaSaldos(List<SaldoRequest> filters);
        Task<List<MovimientoResponse>> ConsultaMovimientos(List<MovimientoRequest> filters);
        
        Task<List<Proceso>> GetListCards(List<Proceso> filters);
        Task<List<CommonResponse>> UpdateStatus(string sessionUser, List<Proceso> values);
    }
}
