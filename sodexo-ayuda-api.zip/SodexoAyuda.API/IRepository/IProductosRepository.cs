﻿using SodexoAyuda.API.Entities;
using SodexoAyuda.API.Entities.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SodexoAyuda.API.IRepository
{
    public interface IProductosRepository
    {
        Task<List<Producto>> ListarProductos();
        Task<CommonResponse> ActualizarBIN(string sessionUser, Producto oDetalle);
    }
}
